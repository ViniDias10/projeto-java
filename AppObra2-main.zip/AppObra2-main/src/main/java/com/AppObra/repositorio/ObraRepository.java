package com.AppObra.repositorio;

import com.AppObra.models.Obra;
import org.springframework.data.repository.CrudRepository;

public interface ObraRepository extends CrudRepository<Obra, String> {

}
