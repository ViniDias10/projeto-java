package com.AppObra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class AppObraApplication {
	public static void main(String[] args) {
		SpringApplication.run(AppObraApplication.class, args);
	}

}
